<script>
	import { onMount } from 'svelte';
	import Cell from './Cell.svelte';
	import { clearGrid, createGrid, createRect, createRoad } from './grid';
	import { canPlaceRoad } from './roads';
	import { max } from './util';

	const w = 10;
	const h = 10;

	let grid = createGrid(w, h);
	const ghostRoadIds = [];
	const createGridRoad = createRoad(grid);

	let startCell, endCell;

	const placeGhostRoad = (cell) => {
		canPlaceRoad(cell) ? (cell.allow = true) : (cell.forbid = true);

		grid = [...grid];
	};

	const clearGhostRoads = () => {
		grid.map((row) =>
			row.map((cell) => {
				cell.forbid = false;
				cell.allow = false;
				cell.s = [];
			})
		);

		grid = [...grid];
	};

	const onOver = (cell) => {
		if (startCell) {
			placeGhostRoad(cell);
		} else {
			placeGhostRoad(cell);
		}

		endCell = cell;
	};

	const onOut = (cell) => {
		if (startCell) {
		} else {
			clearGhostRoads();
		}
	};

	const onStart = (cell) => {
		startCell = cell;
	};

	const onEnd = () => {
		if (!startCell || !endCell) return;

		const rect = createRect(startCell, endCell);

		rect.map(([x, y]) => {
			grid[y][x].road = true;
		});

		grid = [...grid];

		// if (canPlaceRoad(cell)) {
		// 	const interval = createInterval(startCell.x, endCell.x);
		// 	const segment = createSegmentX(interval, startCell.y);
		// 	segment.map(([x, y]) => {
		// 		grid[y][x].road = true;
		// 	});
		// }

		clearGhostRoads();

		startCell = null;
		endCell = null;
	};

	onMount(() => {
		window.addEventListener('mouseup', onEnd);
	});

	const onClearGrid = () => {
		grid = [...clearGrid(grid)];
	};
</script>

<div class="grid">
	{#each grid as row}
		{#each row as cell}
			<!-- svelte-ignore a11y-click-events-have-key-events -->
			<Cell
				{cell}
				on:over-cell={() => onOver(cell)}
				on:out-cell={() => onOut(cell)}
				on:start-cell={() => onStart(cell)}
			/>
		{/each}
	{/each}
</div>

<button on:click={() => onClearGrid()}>Clear</button>

<style>
	:root {
		--cell-size: 70px;
	}

	.grid {
		display: grid;
		grid-template-columns: repeat(10, var(--cell-size));
		grid-template-rows: repeat(10, var(--cell-size));
		column-gap: 2px;
		row-gap: 2px;
	}
</style>

<script>
	import { createEventDispatcher } from 'svelte';

	export let cell;

	const dispatch = createEventDispatcher();

	const mouseOver = (cell) => {
		// console.log('should dispatch over cell', cell);
		dispatch('over-cell', cell);
	};

    const mouseOut = (cell) => {
		// console.log('should dispatch over cell', cell);
		dispatch('out-cell', cell);
	};

	const mouseDown = (cell) => {
		// console.log('should dispatch start cell', cell);
		dispatch('start-cell', cell);
	};

	const mouseUp = (cell) => {
		// console.log('should dispatch end cell', cell);

		dispatch('end-cell', cell);
	};
</script>

<!-- svelte-ignore a11y-click-events-have-key-events -->
<!-- svelte-ignore a11y-mouse-events-have-key-events -->
<div
	class="cell"
	class:road={cell.road}
	class:road-allow={cell.allow}
	class:road-forbid={cell.forbid}
	on:mouseover={() => mouseOver(cell)}
    on:mouseout={() => mouseOut(cell)}
	on:mousedown={() => mouseDown(cell)}
	on:mouseup={() => mouseUp(cell)}
>
	<span class="index">{cell.x},{cell.y}</span>
	<span class="value">
		{cell.value}
	</span>

	{#if cell.s.length}
		<div>
			<span class="tl">{cell.s[0]}</span>
			<span class="tr">{cell.s[1]}</span>
			<span class="bl">{cell.s[2]}</span>
			<span class="br">{cell.s[3]}</span>
		</div>
	{/if}
</div>

<style>
	:root {
		--cell-size: 70px;
	}

	.cell {
		background-color: #c4f8f8;
		display: grid;
		grid-template-rows: 10px 1fr;
		font-size: x-small;
		position: relative;
		user-select: none;
	}

	/* .cell * {
		pointer-events: none;
	} */

	.road {
		background-color: #18ab8d;
	}

	.road-allow {
		background-color: #b4b2f1;
	}

	.road-forbid {
		background-color: #ec6d6d;
	}
	.index {
		display: grid;
		place-items: center;
	}
	.value {
		display: grid;
		place-items: center;
	}

	.tl,
	.tr,
	.bl,
	.br {
		position: absolute;
		color: #eee;
		background-color: #888;
		padding: 2px;
	}

	.tl,
	.tr {
		top: 0;
	}

	.bl,
	.br {
		bottom: 0;
	}

	.tl,
	.bl {
		left: 0;
	}

	.tr,
	.br {
		right: 0;
	}
</style>

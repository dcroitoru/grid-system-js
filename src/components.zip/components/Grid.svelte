<script>
	import Cell from './Cell.svelte';
	import { calcNeighbours, createGrid, createInterval, createRoad, createSegmentX } from './util';

	const w = 10;
	const h = 10;

	let grid = createGrid(w, h);
	const createGridRoad = createRoad(grid);

	// const roads = [createSegment(0, 0, 4), createSegment(0, 2, 4, true)];
	// roads.map((road) => createGridRoad(road));

	// const newRoads = [createSegment(0, 1, 6), createSegment(1, 2, 4, true)];
	// newRoads.map((road) => createGridRoad(road, 2));

	let startCell, endCell;

	const createTempRoad = (startCell, endCell) => {
		if (startCell.x === endCell.x) {
			console.log('vertical not supported');
		}

		const i = createInterval(startCell.x, endCell.x);
		const roadSegment = createSegmentX(i, startCell.y);

		console.log('should add road segment ', roadSegment);

		const road = createGridRoad(roadSegment, 2);
		grid = [...grid];
	};

	const highlightCell = (cell) => {
		const { x, y } = cell;
		const s = calcNeighbours(grid)(x, y);
		const forbid = s.filter((v) => v >= 3).length;

		grid[y][x].s = s;
		if (forbid) {
			grid[y][x].value = 3;
			grid[y][x].forbid = true;
		} else {
			grid[y][x].value = 2;
			grid[y][x].allow = true;
		}

		grid = [...grid];
	};

	const unhghlightCell = ({ x, y }) => {
		grid[y][x].forbid = false;
		grid[y][x].allow = false;
		grid[y][x].s = [];
		grid = [...grid];
	};

	const onOver = (cell) => {
		if (startCell) {
		} else {
			highlightCell(cell);
		}

		// if (!startCell) return;

		// endCell = cell;
		// createTempRoad();
	};

	const onOut = (cell) => {
		if (startCell) {
		} else {
			unhghlightCell(cell);
		}
	};

	const onStart = (cell) => {
		startCell = cell;
	};

	const onEnd = (cell) => {
		console.log('should save road');
		const {x, y} = cell;
		grid[y][x].road = true;
		grid[y][x].value = 1;
		unhghlightCell(cell);


		startCell = null;
		endCell = null;
	};

	const clearGrid = () => {
		grid = [...grid.map((row) => row.map((cell) => ({ ...cell, value: 0, s: [] })))];
	};
</script>

<div class="grid">
	{#each grid as row}
		{#each row as cell}
			<!-- svelte-ignore a11y-click-events-have-key-events -->
			<Cell
				{cell}
				on:over-cell={() => onOver(cell)}
				on:out-cell={() => onOut(cell)}
				on:start-cell={() => onStart(cell)}
				on:end-cell={() => onEnd(cell)}
			/>
		{/each}
	{/each}
</div>

<button on:click={() => clearGrid()}>Clear</button>

<style>
	:root {
		--cell-size: 70px;
	}

	.grid {
		display: grid;
		grid-template-columns: repeat(10, var(--cell-size));
		grid-template-rows: repeat(10, var(--cell-size));
		column-gap: 2px;
		row-gap: 2px;
	}
</style>
